#!/usr/bin/perl

# This is a stand-alone script to run in any supersite, which handles
# BOUNCES back to the mail sending address, start@sun.softconf.com.
# It is run via the forward file in the home directory for user
# "start".  The objective is to send the NDR back to the person
# who send the original mail from softconf.

require "parameters.pl";

my @out = ();
while (<>) {
    push(@out, $_);
}

# If the header X-START-Originating is not present, we discard this msg.
my @return = grep (/X-START-Originating:/,@out);
if ($#return != 0) {
    exit;
}

# Check to see if we already processed this mail, and it happened
# to also bounce back from the X-START-Originating address.
# If so, we get out of here.
my @loop = grep (/X-START-Processed:/,@out);
if (@loop) {
    exit;
}

# Get any whitespace out of the address.
my $addr = join("",split(/X-START-Originating: /,join("",@return)));
$addr =~ s/[\s\n]*//g;

my @subs = grep (/X-START-Subject: /,@out);
my $subjectline = $subs[0];
$subjectline =~ /^(X-START-Subject:)(\s*)(.+)$/i;
$subjectline = $3;


while (!(open(MAIL, "|$sendmailPath -oi -t > /dev/null"))) {
    sleep 1;
}
binmode MAIL;
print MAIL "MIME-Version: 1.0\n";
print MAIL "Content-Type: text/plain; ";
print MAIL "charset=UTF-8\n";
print MAIL "X-START-Processed: Yes\n";
print MAIL "To: $addr\n";
print MAIL "Subject: START Delivery Failure - $subjectline\n\n";
print MAIL<<EOM;
START V2 attempted to send the following mail on your behalf, but it could not
be delivered.  For details, see the transcript below.  The report was generated 
by the remote MTA which processed the mail.  We are merely forwarding that MTA's 
failure message back to you.  

Do not reply to this mail.  Incoming mail to this address is discarded.

=========================================================================

EOM

print MAIL @out;
close(MAIL);


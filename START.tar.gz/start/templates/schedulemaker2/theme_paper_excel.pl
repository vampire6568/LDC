# Template used for the first time in ISQUED09

$schedulemaker2_excel_paper_col_caption = 
    'Paper ID'                    . $logsep .
    'Paper Time'                  . $logsep .
    'Paper End Time'              . $logsep .
    'Paper Subcode'               . $logsep .
    'Paper Flag'                  . $logsep .
    'Paper Presenter'             . $logsep .
    'Paper Title'                 . $logsep .
    'Paper Authors'               . $logsep .
    'Paper Affiliations'          . $logsep .
    'Paper Corresponding Authors' . $logsep .
    'Paper Phone'                 . $logsep .
    'Paper Email'                 . $logsep;
$schedulemaker2_excel_paper_col_num = 11;

sub generate_paper() {
    $paperID = $thePaperID;
    $X_Slot = $paper_subcode;

    @theAuthorList = ();
    @theAffiliationList = ();
    @theAddressList = ();

    my @theContacts = ();
    
    my @XtheContacts = (keys %contact);

    my @_names = ();

    foreach my $thisOne (@XtheContacts) {
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $thisName = "$fn$ln";
	if ($fn && $ln) {
	    push @theContacts, $thisOne;
	    push @_names, $thisName;
	}
    }
    # _names contains PaoloGai,RichGerber
    # theContacts contains 1,2

    # now removes duplicate names
    @XtheContacts = @theContacts;
    @theContacts = ();
    while (@XtheContacts) {
	my $thisOne = shift @XtheContacts;
	my $thisName = shift @_names;
	if (!(grep(/^$thisName$/, @_names))) {
	    push @theContacts, $thisOne;
	}
    }

    @theContacts = sort {bynum()} @theContacts;

    foreach my $thisOne (@theContacts) {
	
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	if ($fn =~ /\//) {
	    my @fnList = split(/\b*\/\b*/, $fn);
	    my $mI = $fnList[1];
	    $mI =~ s/\.//g;
	    $mI .= '.';
	    $fn = qq{$fnList[0] $mI};
	}
	
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $thisName = "$fn $ln";

	push @theAuthorList, $thisName;

	my $aff = killtheSpace($contact{$thisOne}{Affiliation});
	$aff =~ s/\n//g;
	push @theAffiliationList, $aff;

	$sup[$thisOne-1] = ();
    }

# OK, now that we have the names, affiliations, and addresses,
# let's get the superscripts in there correctly.
 

    $supAddress = q{};
    @supAuthorList = ();
    
    my $supCT = 1;
    my @sup = ();
    for (my $i = 0; $i <= $#theAffiliationList; $i++) {
	if (!$sup[$i]) {
	    $sup[$i] = $supCT++;
	    $supAuthorList[$i] = 
		qq{$theAuthorList[$i] [$sup[$i]]};
	    $supAddress .= qq{[$sup[$i]] $theAffiliationList[$i]\n};
	}
	for (my $j = $i+1; $j <= $#theAffiliationList; $j++) {
	    if (!$sup[$j]) {
		if (lc($theAffiliationList[$i]) eq 
		    lc($theAffiliationList[$j])) {
		    $sup[$j] = $sup[$i];
		    $supAuthorList[$j] = 
			qq{$theAuthorList[$j] [$sup[$i]]};
		}
	    }
	}
    }

    $supAddress .= qq{};
    
    $X_Address = ();

    if ($supCT eq 2) {
	$X_Address .= qq{$theAffiliationList[0], };
    }
    else {
	$X_Address = $supAddress;
	@theAuthorList = @supAuthorList;
    }
    
    $X_Address =~ s/(,[ ])*$//;
    $X_Address =~ s/^([ ]*,)//;
    $X_Address =~ s/\Q,\E//g;

    $X_Authors = ();
    if ($#theAuthorList eq 0) {
	$X_Authors = $theAuthorList[0];
    }
    if ($#theAuthorList eq 1) {
	$X_Authors = qq{$theAuthorList[0] and $theAuthorList[1]};
    }
    
    if ($#theAuthorList > 1) {
	$X_Authors = join(',  ', @theAuthorList);
    }
    
    $X_Email = $email;
    $X_Email = qq{$X_Email };
    
    $X_Title = killtheSpace($title);
    $X_Title =~ s/\n//g;

#    $T_StartTime = deNormalizeTime($paper_time);
    $T_StartTime = $paper_time;
    $V_StartTime = $T_StartTime;
    $T_EndTime = $paper_endtime;
    $V_EndTime = $T_EndTime;
    if (!$record) {
	for ($i=0; $i<$schedulemaker2_excel_day_col_num+$schedulemaker2_excel_section_col_num; $i++) {
	    $record .= $logsep;
	}
    }
    $record .=
	$paperID                                   . $logsep .
	$V_StartTime                               . $logsep .
        $V_EndTime                                 . $logsep .
	$X_Slot                                    . $logsep .
	$paper_flag                                . $logsep .
	$paper_presenter                           . $logsep .
	$X_Title                                   . $logsep .
	$X_Authors                                 . $logsep .
	$X_Address                                 . $logsep .
	$contactFirstname . ' ' . $contactLastname . $logsep .
	$contactPhone                              . $logsep .
	$email                                     . $logsep;

    if (defined &generate_conference_excel_generateline) {
	generate_conference_excel_generateline();
    }

    return '';

}

1;

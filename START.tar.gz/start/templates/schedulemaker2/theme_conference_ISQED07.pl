# Template used for the first time in ISQED07

sub generate_conference_header() {
  $Summary = evalCustFile('schedulemaker2/theme_conference_ISQED07_header.html');
}

sub generate_conference_footer() {
  $Summary .= evalCustFile('schedulemaker2/theme_conference_ISQED07_footer.html');

  # write the file!
  open(THEFILE, ">$acceptedDir/accepted.html");
  binmode(THEFILE);
  print THEFILE "$Summary";
  close THEFILE;
}

1;

# Template used for the first time in RTSS08

sub generate_conference_header() {
  $Summary = evalCustFile('schedulemaker2/theme_conference_text_header.txt') . "\n\n";
}

sub generate_conference_footer() {
  $Summary .=  evalCustFile('schedulemaker2/theme_conference_text_footer.txt');

  # write the file!
  open(THEFILE, ">$acceptedDir/accepted.txt");
  binmode(THEFILE);
  print THEFILE "$Summary";
  close THEFILE;
}

1;

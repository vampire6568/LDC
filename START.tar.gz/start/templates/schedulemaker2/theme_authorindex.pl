# AuthorIndex support files

# this file contains a set of support functions currently used (at
# least) by the DIMVA theme to create an author index


# author index database
%authorindex_paperid = (); # a hash of arrays
%authorindex_firstname = ();
%authorindex_lastname = ();
%authorindex_affiliation = ();


############################################################################
# authorindex_push
#
# Description: This function is used to push the pair
# (author,paperid), which will be used afterwards to create the
# authorindex.
#
# Parameters:
# - paperid
# - firstname
# - lastname
# - affiliation
sub authorindex_push {
  my $pid = shift @_;
  my $fn = shift @_;
  my $ln = shift @_;
  my $af = shift @_;

  # let's create a unique hash for this author
  my $thekey = $fn . $logsep . $ln . $logsep . $af;

  # store the information about the author
  $authorindex_firstname{$thekey} = $fn;
  $authorindex_lastname{$thekey} = $ln;
  $authorindex_affiliation{$thekey} = $af;
  push @{$authorindex_paperid{$thekey}}, $pid;
}

sub byauthor {
  if ($authorindex_lastname{$a} ne $authorindex_lastname{$b}) {
    return $authorindex_lastname{$a} cmp $authorindex_lastname{$b};
  } elsif ($authorindex_firstname{$a} ne $authorindex_firstname{$b}) {
    return $authorindex_firstname{$a} cmp $authorindex_firstname{$b};
  } else {
    return $authorindex_affiliation{$a} cmp $authorindex_affiliation{$b};
  }
}

sub authorindex_getorder {
  my @thekeys = keys %authorindex_firstname;

  #my @theorder = sort @thekeys; #{ byauthor() } @thekeys;
  my @theorder = sort { byauthor() } @thekeys;

  return @theorder;
}





1;

# Template used for the first time in RTSS08

sub generate_genericspeech() {
  # empty
}

1;

sub generate_conference_header() {
  if ($trackName) {
    importTrackInfo();
    getUserInfo();

    # create the list of track managers as seen in the track administration console
    @_currAdminList = ();
    if (%{$TrackAdmin{$trackName}}) {
      my @tguys = (values %{$TrackAdmin{$trackName}});
      if (@tguys) {
	push @_currAdminList, @tguys;
      }
    }
    # Get the current administrators which may not be entered via the multi-track console;
    push @_currAdminList, getUsersInGroup($trackName . '_manager');
    @_currAdminList = uniq(\@_currAdminList); # no dups.
    @_currAdminList = grep {($_)} @_currAdminList;  # no empties;

    foreach $tm (@_currAdminList) {
      $trackchairlist .=<<EOM;
   <li>$FirstName{$tm} $LastName{$tm} ($Email{$tm}@{[$Affiliation{$tm} ? qq{, $Affiliation{$tm}}:qq{}]})</li>
EOM
    }
  }


  $Summary = evalCustFile('schedulemaker2/theme_conference_DATE_header.html');
}

sub generate_conference_footer() {
  $Summary .= evalCustFile('schedulemaker2/theme_conference_DATE_footer.html');

  my @_FXList = ("schedule.css");

  foreach my $_file (@_FXList) {
    copy("$templates/schedulemaker2/theme_conference_DATE_files/$_file", "$acceptedDir/$_file");
  }

  # write the file!
  open(THEFILE, ">$acceptedDir/accepted.html");
  binmode(THEFILE);
  print THEFILE "$Summary";
  close THEFILE;
}

1;

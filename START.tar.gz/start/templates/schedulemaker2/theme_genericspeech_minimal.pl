sub generate_genericspeech() {
    $Summary .=<<EOM;
<blockquote>
    <table>
      <tr>
	<td>
	  $genericspeech_time@{[($genericspeech_endtime) ? qq{ - $genericspeech_endtime} : ()]}
 &nbsp;&nbsp;
	</td>
	<td>
	  @{[($genericspeech_subcode) ? qq{$genericspeech_subcode - } : qq{}]}
	  $genericspeech_title

	  @{[($genericspeech_presenter) ? qq{
	  (Presenter: $genericspeech_presenter)
	  } : qq{} ]}
	</td>
      </tr>
    </table>
</blockquote>
EOM
}

1;

# Template used for the first time in ISQUED09


$schedulemaker2_excel_section_col_caption = 
  'Section title'           . $logsep .
  'Section description'     . $logsep .
  'Section code'            . $logsep .
  'Section time'            . $logsep .

  'Section end time'        . $logsep .
  'Section room'            . $logsep .
  'Section chair'           . $logsep .
  'Section chair first name'. $logsep .

  'Section chair aff.'      . $logsep .
  'Section chair email'     . $logsep .
  'Section chair country'   . $logsep .
  'Section chair phone'     . $logsep .

  'Section cochair'         . $logsep .
  'Section cochair first name' . $logsep .
  'Section cochiar aff.'    . $logsep .
  'Section cochair email'   . $logsep .

  'Section cochair country' . $logsep .
  'Section cochair phone'   . $logsep;
$schedulemaker2_excel_section_col_num = 18;

sub generate_section() {
  if (!$record) {
    for ($i=0; $i<$schedulemaker2_excel_day_col_num; $i++) {
      $record .= $logsep;
    }
  }
  $record .=
	$section_title          . $logsep .
	$section_description    . $logsep .
	$section_code           . $logsep .
	$section_time           . $logsep .

	$section_endtime        . $logsep .
	$section_room           . $logsep .
	$section_chair          . $logsep .
	$section_chairfirstname . $logsep .

	$section_chairaff       . $logsep .
	$section_chairemail     . $logsep .
	$section_chaircountry   . $logsep .
	$section_chairphone     . $logsep .

	$section_cochair        . $logsep .
	$section_cochairfirstname . $logsep .
	$section_cochairaff     . $logsep .
	$section_cochairemail   . $logsep .

	$section_cochaircountry . $logsep .
	$section_cochairphone   . $logsep;

  if (defined &generate_conference_excel_generateline) {
    generate_conference_excel_generateline();
  }
  return '';
}

1;


sub generate_paper() {
    $thetitle = escapeTEX($title);
    
    my $thefile = $fileUploadName{$PDFAttachment1_current};
    $thefile =~ s/\Q$logsep\E/$paperID/g;

    if (-e "$thefile.pdf") {
	$theerror = 0;
	copy("$thefile.pdf", "$acceptedDir/data/$thePaperID.pdf");
    } else {
	$theerror = 1;
    }

    $thefilename = $thePaperID;
    $texFile .= evalCustFile("schedulemaker2/theme_paper_pdf_skip.tex");

    return '';

}

1;

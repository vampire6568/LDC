
sub generate_conference_header() { 
  # Create a set of Excel Data structures which will be filled by the various items
  @theData = ();
  
  push @theData, "Presentation Code" . $logsep . "Title" . $logsep . "Abstract and Authors" . $logsep . "Authors Ony". $logsep;
  
}

sub generate_conference_footer() {
  
  # generate the captions
    
  # write the file!
  open(THEFILE, ">$acceptedDir/accepted.xls");
  binmode(THEFILE);
  print THEFILE text_to_excel( data      => \@theData,
			       delimiter => $logsep,
			       name      => 'Current Schedule');
  close THEFILE;
}

sub generate_conference_excel_generateline() {

    # the if is needed because this function is called at the footer
    # of day and section, and on the generation of papers and
    # genericspeech. Consider for example a section footer. If a
    # section does not contain a paper, then the call generates a line
    # with day+section. but if the section contains a paper, then the
    # $record variable is emptied by the paper generation and nothing
    # needs to be printed.
    if ($record) {
	push @theData, $record;
	$record='';
    }
}


1;

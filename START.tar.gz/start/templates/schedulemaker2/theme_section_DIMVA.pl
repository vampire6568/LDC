sub generate_section() {
  $Summary .= evalCustFile('schedulemaker2/theme_section_DIMVA_header.html');
}


1;

# Template used for the first time in RTSS08

sub generate_day() {
  $Summary .= evalCustFile('schedulemaker2/theme_day_DIMVA.html');
}


1;

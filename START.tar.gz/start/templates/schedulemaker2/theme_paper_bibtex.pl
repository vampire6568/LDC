sub generate_paper() {
    $paperID = $thePaperID;
    $X_Slot = $paper_subcode;

    @theAuthorList = ();
    @theAffiliationList = ();
    @theAddressList = ();

    my @theContacts = ();
    
    my @XtheContacts = (keys %contact);

    my @_names = ();

    foreach my $thisOne (@XtheContacts) {
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $thisName = "$fn$ln";
	if ($fn && $ln) {
	    push @theContacts, $thisOne;
	    push @_names, $thisName;
	}
    }
    # _names contains PaoloGai,RichGerber
    # theContacts contains 1,2

    # now removes duplicate names
    @XtheContacts = @theContacts;
    @theContacts = ();
    while (@XtheContacts) {
	my $thisOne = shift @XtheContacts;
	my $thisName = shift @_names;
	if (!(grep(/^$thisName$/, @_names))) {
	    push @theContacts, $thisOne;
	}
    }

    @theContacts = sort {bynum()} @theContacts;

    foreach my $thisOne (@theContacts) {
	
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	if ($fn =~ /\//) {
	    my @fnList = split(/\b*\/\b*/, $fn);
	    my $mI = $fnList[1];
	    $mI =~ s/\.//g;
	    $mI .= '.';
	    $fn = qq{$fnList[0] $mI};
	}
	
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $thisName = "$fn $ln";

	push @theAuthorList, $thisName;
    }

    $X_Authors = join(' and ', @theAuthorList);

    $X_Title = killtheSpace($title);
    $X_Title =~ s/\n//g;

    $bibtex_papercode = lc($ACRONYM_YR . ':' . substr($contactFirstname,0,1) . $contactLastname);
    $bibtex_papercode =~ s/ //g;

    # look for a paper code not yet used
    $bibtex_suffix = '';
    $i = 1;
    do {
      $X_bibtex_papercode = $bibtex_papercode . $bibtex_suffix;

      if ($bibtex_papercodes{$X_bibtex_papercode}) {
	# found. try another one
	$bibtex_suffix = $i;
	$i++;
	$myexit = 1;
      } else {
	# not found. we can exit
	$bibtex_papercodes{$X_bibtex_papercode} = 1;
	$myexit = 0;
      }
    } while ($myexit);


    $Summary .= evalCustFile("schedulemaker2/theme_paper_bibtex_each.txt"). "\n\n";
}

1;

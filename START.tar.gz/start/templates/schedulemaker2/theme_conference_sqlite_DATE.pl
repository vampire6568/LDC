# Template used for the first time in RTSS08


sub generate_conference_header() {
  initFinalStatusLog();

  $SQL_output =<<EOM;
SET time_zone = "CET";
SET NAMES utf8;
EOM

  # insert DATE topics
  my @tracks = orderTracks();
  my $topic_id=1;
  foreach my $tname (sort @tracks) {
    my $RealName = $TrackName{$tname};

    $SQL_output .=<<EOM;

INSERT INTO `topics` (`topic_id`, `track_id`, `label`, `title`, `link`, `description`, `data_from`) VALUES (
@{[SQL_escape_integer($topic_id)]},
NULL,
NULL,
@{[SQL_escape($RealName)]},
NULL,
NULL,
'SoftConf'
);
EOM
    $topic_numbers{$tname} = $topic_id;
    $topic_id++;
  }

  my @_theKeys_ = do "$templates/submitPaper/countryCodes.txt";
  my @_theLabels_ = do "$templates/submitPaper/countries.txt";

  foreach my $k (@_theKeys_) {
    my $n = shift @_theLabels_;
    if ($k) {
      $SQL_output .=<<EOM;
          INSERT INTO `START_countries` VALUES ('$k','$n');
EOM
    }
  }


}

sub generate_conference_footer() {
  open(THEFILE, ">$acceptedDir/accepted.sql");
  binmode(THEFILE);
  print THEFILE "$SQL_output";
  close THEFILE;

  system "cd $acceptedDir; echo \"<pre>\" >accepted.html; cat accepted.sql >>accepted.html; echo \"</pre>\" >>accepted.html";
}

1;

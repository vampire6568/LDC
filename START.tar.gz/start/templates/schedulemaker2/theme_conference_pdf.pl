# Template used for PDF Proceedings generation

# the idea of this template is to generate a single PDF file by using
# latex and PDFpages.

sub generate_conference_header() {

    # create the directory where the PDF files will be put
    mkdir("$acceptedDir/data") || skip;

    # call this to prepare the data for the papers
    getPDFFields();

    # Initialize the TeX file
    $texFile = evalCustFile("schedulemaker2/theme_conference_pdf_header.tex");
}

sub generate_conference_footer() {

   $texFile .= "\\end{document}";

    open(TEXFILE, ">$acceptedDir/data/proceedings.tex");
    binmode(TEXFILE);
    print TEXFILE "$texFile";
    close TEXFILE;

    system "echo --- PDFLATEX First pass ---------------------------  > $acceptedDir/data/proceedings.output";
    system "cd $acceptedDir/data; pdflatex proceedings >> proceedings.output";
    system "echo --- PDFLATEX Second pass --------------------------  >> $acceptedDir/data/proceedings.output";
    system "cd $acceptedDir/data; pdflatex proceedings >> proceedings.output";
    system "echo --- PDFLATEX Third pass ---------------------------  >> $acceptedDir/data/proceedings.output";
    system "cd $acceptedDir/data; pdflatex proceedings >> proceedings.output";

    if (-e "$acceptedDir/data/proceedings.pdf") {
	copy("$acceptedDir/data/proceedings.pdf", "$acceptedDir/accepted.pdf");
    }
}



1;

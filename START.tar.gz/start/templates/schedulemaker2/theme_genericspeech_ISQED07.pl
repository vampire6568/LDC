# Template used for the first time in ISQED07

sub generate_genericspeech() {
    $Summary .= evalCustFile("schedulemaker2/theme_genericspeech_ISQED07_each.html");
}

1;

# Template used for the first time in RTSS08

sub generate_day() {
  $Summary .=<<EOM;
    <b>$day_date</b><p>

EOM
}


1;

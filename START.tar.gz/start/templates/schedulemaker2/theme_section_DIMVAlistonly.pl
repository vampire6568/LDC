sub generate_section() {
  $sectionnolinks=1;
  $Summary .= evalCustFile('schedulemaker2/theme_section_DIMVA_header.html');
  $sectionnolinks=0;
}


1;

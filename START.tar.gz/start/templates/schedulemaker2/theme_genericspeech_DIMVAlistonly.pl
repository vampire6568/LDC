sub generate_genericspeech() {
  $genericspeechnolinks=1;
  $Summary .= evalCustFile("schedulemaker2/theme_genericspeech_DIMVA_each.html");
  $genericspeechnolinks=0;
}

1;

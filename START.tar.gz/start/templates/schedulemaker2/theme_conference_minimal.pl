sub generate_conference_header() {
  $Summary =<<EOM;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <TITLE>$ACRONYM_YR:  Program</TITLE>
  </head>
  <body>
    <p>
      <h1>$ACRONYM_YR: Program</h1>
EOM
}

sub generate_conference_footer() {
  $Summary .=<<EOM;
  <hr>
  </body>
</html>
EOM

  # write the file!
  open(THEFILE, ">$acceptedDir/accepted.html");
  binmode(THEFILE);
  print THEFILE "$Summary";
  close THEFILE;
}

1;

# Template used for the first time in ISQED07

sub generate_section() {
  $Summary .= evalCustFile('schedulemaker2/theme_section_UGSymp2007_header.html');
}

1;

sub generate_genericspeech() {
  $SummaryMainSched .= evalCustFile("schedulemaker2/theme_genericspeech_CS_each.html");
}

1;

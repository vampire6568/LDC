sub generate_section() {
  $Summary .= evalCustFile('schedulemaker2/theme_section_DATE_header.html');
}


1;

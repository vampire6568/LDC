# Template used for the first time in ISQUED09

sub generate_section() {
    $texFile .= evalCustFile("schedulemaker2/theme_section_pdf_header.tex");
    return '';
}

1;

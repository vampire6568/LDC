# Template used for the first time in ISQED07, adapted then for DIMVA

sub generate_paper() {
    $paperID = $thePaperID;
    $X_Slot = $paper_subcode;
    $X_Underline = ($paper_flag =~ /U/i) ? 1 : 0;

    @theAuthorList = ();
    @theAffiliationList = ();
    @theAddressList = ();

    my @theContacts = ();
    
    my @XtheContacts = (keys %contact);

    my @_names = ();

    foreach my $thisOne (@XtheContacts) {
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $af = killtheSpace($contact{$thisOne}{Affiliation});
	my $thisName = "$fn$ln";
	if ($fn && $ln) {
	    push @theContacts, $thisOne;
	    push @_names, $thisName;

	    authorindex_push($paperID, $fn, $ln, $af);
	}
    }
    # _names contains PaoloGai,RichGerber
    # theContacts contains 1,2

    # now removes duplicate names
    @XtheContacts = @theContacts;
    @theContacts = ();
    while (@XtheContacts) {
	my $thisOne = shift @XtheContacts;
	my $thisName = shift @_names;
	if (!(grep(/^$thisName$/, @_names))) {
	    push @theContacts, $thisOne;
	}
    }

    @theContacts = sort {bynum()} @theContacts;

    foreach my $thisOne (@theContacts) {
	
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	if ($fn =~ /\//) {
	    my @fnList = split(/\b*\/\b*/, $fn);
	    my $mI = $fnList[1];
	    $mI =~ s/\.//g;
	    $mI .= '.';
	    $fn = qq{$fnList[0] $mI};
	}
	
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $thisName = "$fn $ln";

	push @theAuthorList, $thisName;

	my $aff = killtheSpace($contact{$thisOne}{Affiliation});
	$aff =~ s/\n//g;
	push @theAffiliationList, $aff;

	$sup[$thisOne-1] = ();
    }

# OK, now that we have the names, affiliations, and addresses,
# let's get the superscripts in there correctly.
 

    $supAddress = q{<table cellpadding=0 cellspacing=0>};
    @supAuthorList = ();
    
    my $supCT = 1;
    my @sup = ();
    for (my $i = 0; $i <= $#theAffiliationList; $i++) {
	if (!$sup[$i]) {
	    $sup[$i] = $supCT++;
	    $supAuthorList[$i] = 
		qq{$theAuthorList[$i]<sup>$sup[$i]</sup>};
	    $supAddress .= qq{<tr><td valign=top><sup>$sup[$i]</sup>$theAffiliationList[$i]</td></tr>};
	}
	for (my $j = $i+1; $j <= $#theAffiliationList; $j++) {
	    if (!$sup[$j]) {
		if (lc($theAffiliationList[$i]) eq 
		    lc($theAffiliationList[$j])) {
		    $sup[$j] = $sup[$i];
		    $supAuthorList[$j] = 
			qq{$theAuthorList[$j]<sup>$sup[$i]</sup>};
		}
	    }
	}
    }

    $supAddress .= qq{</table>};
    
    $X_Address = ();

    if ($supCT eq 2) {
	$X_Address .= qq{$theAffiliationList[0], };
    }
    else {
	$X_Address = $supAddress;
	@theAuthorList = @supAuthorList;
    }
    
    $X_Address =~ s/(,[ ])*$//;
    $X_Address =~ s/^([ ]*,)//;
    $X_Address =~ s/\Q<td valign=top>,\E/<td valign=top>/g;

    $X_Authors = ();
    if ($#theAuthorList eq 0) {
	$X_Authors = $theAuthorList[0];
    }
    if ($#theAuthorList eq 1) {
	$X_Authors = qq{$theAuthorList[0] and $theAuthorList[1]};
    }
    
    if ($#theAuthorList > 1) {
	$X_Authors = join(',&nbsp;&nbsp;', @theAuthorList);
    }
    
    $X_Email = $email;
    $X_Email = qq{<a href="mailto:$X_Email">$X_Email</a>};
    
    $X_Title = killtheSpace($title);
    $X_Title =~ s/\n//g;

    $T_StartTime = $paper_time;
    $T_EndTime = $paper_endtime;
#    $T_StartTime = deNormalizeTime($paper_time);
#   $T_Duration = $SchedRow{$pres}{paperDuration}; seems not used for ISQED

#    my @_paperFiles = bsd_glob("$PC/papers/$paperID.*");
#    foreach my $abFile (@_paperFiles) {
#	copy($abFile, "$acceptedDir");
#    }
    
#    local $MANUSCRIPTS = makeMSList($paperID);
#    $MANUSCRIPTS =~ s/scmd.cgi\?scmd=getPaper\&//g;
#    $MANUSCRIPTS =~ s/paperID=$paperID//g;
#    $MANUSCRIPTS =~ s/\&filename=//g;
    

    $V_StartTime = $T_StartTime;
    $V_StartTime =~ s/ //g;
    $V_EndTime = $T_EndTime;
    $V_EndTime =~ s/ //g;
    $V_Address = $X_Address;
    $V_Address =~ s/(\<table)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<\/table)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<td)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<\/td)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<tr)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<\/tr)([^\>]*)(\>)/, /g;
    $V_Address =~ s/(,[ ])*$//;
    $V_Address =~ s/^([ ]*,)//;

    evalCustFileToFile("schedulemaker2/theme_paper_DIMVA_eachabstract.html",
		   "$acceptedDir/$paperID.html");

    # handle PDF paper 1
    my $thefile = $fileUploadName{$PDFAttachment1_current};
    $thefile =~ s/\Q$logsep\E/$paperID/g;
    my @_paperFiles = bsd_glob("$thefile.*");
    my $XYZ_newFile = ();
    $YYYZ_newFile = ();
    while (@_paperFiles) {
	$XYZ_newFile = pop @_paperFiles;
	if ($XYZ_newFile =~ /pdf/) {
	    @_paperFiles = ();
	}
    }
    if (-e "$XYZ_newFile") {
	$paper1_present = 1;
	$paper1_newFile = fname($XYZ_newFile);
	copy("$XYZ_newFile", "$acceptedDir/$paper1_newFile");
    } else {
	$paper1_present = 0;
    }

    # handle PDF paper 2
    my $thefile = $fileUploadName{$PDFAttachment2_current};
    $thefile =~ s/\Q$logsep\E/$paperID/g;
    my @_paperFiles = bsd_glob("$thefile.*");
    my $XYZ_newFile = ();
    $YYYZ_newFile = ();
    while (@_paperFiles) {
	$XYZ_newFile = pop @_paperFiles;
	if ($XYZ_newFile =~ /pdf/) {
	    @_paperFiles = ();
	}
    }
    if (-e "$XYZ_newFile") {
	$paper2_present = 1;
	$paper2_newFile = fname($XYZ_newFile);
	copy("$XYZ_newFile", "$acceptedDir/$paper2_newFile");
    } else {
	$paper2_present = 0;
    }

    # handle PDF paper 3
    my $thefile = $fileUploadName{$PDFAttachment3_current};
    $thefile =~ s/\Q$logsep\E/$paperID/g;
    my @_paperFiles = bsd_glob("$thefile.*");
    my $XYZ_newFile = ();
    $YYYZ_newFile = ();
    while (@_paperFiles) {
	$XYZ_newFile = pop @_paperFiles;
	if ($XYZ_newFile =~ /pdf/) {
	    @_paperFiles = ();
	}
    }
    if (-e "$XYZ_newFile") {
	$paper3_present = 1;
	$paper3_newFile = fname($XYZ_newFile);
	copy("$XYZ_newFile", "$acceptedDir/$paper3_newFile");
    } else {
	$paper3_present = 0;
    }



    $Summary .= evalCustFile("schedulemaker2/theme_paper_DIMVA_each.html");
}

1;

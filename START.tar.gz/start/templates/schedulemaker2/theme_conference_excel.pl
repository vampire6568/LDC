# Template used for the first time in ISQUED09, ticket 101411

# the idea of this template is to generate an excel spreadsheet. 

# to do that, each template (day, section, paper, genericitem has to
# declare the number of columns it will add, and their
# descriptions. This is done in a set of global variables, which
# contains a set of values that will be used when generating the excel
# file.

# The excel file generation is done in the footer, and is the result
# of the accumulation of all the results of the previous items.

# If the selected items are not all of the Excel type, then THE
# GENERATION WILL NOT WORK because the Summary variable in the main
# file will be dirtied :-( (to avoid this I should write the generator
# in a different way, but let's skip this for the moment.


sub generate_conference_header() { 
  # Create a set of Excel Data structures which will be filled by the various items
  @theData = ();
  
  push @theData, $schedulemaker2_excel_day_col_caption . 
      $schedulemaker2_excel_section_col_caption . 
      $schedulemaker2_excel_paper_col_caption . 
      $schedulemaker2_excel_genericspeech_col_caption;
  
  # Initialize the record
  $record = '';
}

sub generate_conference_footer() {
  
  # generate the captions
    
  # write the file!
  open(THEFILE, ">$acceptedDir/accepted.xls");
  binmode(THEFILE);
  print THEFILE text_to_excel( data      => \@theData,
			       delimiter => $logsep,
			       name      => 'Current Schedule');
  close THEFILE;
}

sub generate_conference_excel_generateline() {

    # the if is needed because this function is called at the footer
    # of day and section, and on the generation of papers and
    # genericspeech. Consider for example a section footer. If a
    # section does not contain a paper, then the call generates a line
    # with day+section. but if the section contains a paper, then the
    # $record variable is emptied by the paper generation and nothing
    # needs to be printed.
    if ($record) {
	push @theData, $record;
	$record='';
    }
}


# sets a default value for the column numbers
if (!defined $schedulemaker2_excel_day_col_num) {
    $schedulemaker2_excel_day_col_num = 0;
    $schedulemaker2_excel_day_col_caption = '';
}

if (!defined $schedulemaker2_excel_section_col_num) {
    $schedulemaker2_excel_section_col_num = 0;
    $schedulemaker2_excel_section_col_caption = '';
}

if (!defined $schedulemaker2_excel_paper_col_num) {
    $schedulemaker2_excel_paper_col_num = 0;
    $schedulemaker2_excel_paper_col_caption = '';
}

if (!defined $schedulemaker2_excel_genericspeech_col_num) {
    $schedulemaker2_excel_genericspeech_col_num = 0;
    $schedulemaker2_excel_genericspeech_col_caption = '';
}







1;

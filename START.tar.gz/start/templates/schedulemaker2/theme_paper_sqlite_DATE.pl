# Template used for the first time in RTSS2008. derived from ISQED07 version

sub generate_paper() {
  my @thetracks = keys %{$PaperTrack{$thePaperID}};
  my $thefirsttrack = shift @thetracks;

  my $submitted_topic = $CategorySelection{1};
  my @trlist = orderTracks();
  foreach my $t (@trlist) {
    if ($TrackName{$t} eq $submitted_topic) {
      $submitted_topic_index = $topic_numbers{$t};
      last;
    }
  }

  $order_id++;

  $SQL_output .=<<EOM;

INSERT INTO `submissions` (`submission_id`, `title`, `authors`, `abstract`, `submission_type`, `duration`, `topic_id`, `othertopic`, `submitted_topic`, `emphasis`, `conflict`, `firstname`, `familyname`, `affiliation`, `category`, `address1`, `address2`, `city`, `zip`, `country`, `tel`, `fax`, `email`, `comment`, `password`, `time`, `status`, `data_from`) VALUES (
	   @{[SQL_escape_integer($thePaperID)]},
	   @{[SQL_escape($title)]},
	   @{[SQL_escape($authors)]},
	   @{[SQL_escape($abstract)]},

	   @{[SQL_escape($CategorySelection{1})]},
  	   NULL,
	   @{[SQL_escape_integer($topic_numbers{$thefirsttrack})]},
	   NULL,

	   @{[SQL_escape_integer($submitted_topic_index)]},
	   NULL,
	   NULL,
	   @{[SQL_escape($contactFirstname)]},

	   @{[SQL_escape($contactLastname)]},
	   @{[SQL_escape($contactAffiliation)]},
	   NULL,
	   @{[SQL_escape($streetAddress_1)]},

	   @{[SQL_escape($streetAddress_2)]},
  	   @{[SQL_escape($contactTown)]},
	   @{[SQL_escape($contactZip)]},
  	   @{[SQL_escape($contactCountry)]},

	   @{[SQL_escape($contactPhone)]},
  	   @{[SQL_escape($contactFax)]},
	   @{[SQL_escape($email)]},
  	   NULL,

  	   NULL,
  	   NULL,
  	   @{[SQL_escape($PaperStatus{$paperID})]},
           'SoftConf'
	   ) ON DUPLICATE KEY UPDATE submission_id = @{[SQL_escape_integer($thePaperID)]};

EOM

  if (!$DATE_webservice_skip_presentations) {
    $SQL_output .=<<EOM;
INSERT INTO `presentations` (`session_id`, `presentation_id`, `presentation_type`, `presentation_best`, `presentation_best_silicon`, `order`, `label`, `start`, `end`, `data_from`) VALUES (
	   @{[SQL_escape_integer($latest_sessionid)]},
	   @{[SQL_escape_integer($thePaperID)]},
	   NULL,

	   @{[SQL_escape($paper_bestpaper)]},
	   NULL,
	   @{[SQL_escape_integer($order_id)]},

	   @{[SQL_escape($paper_subcode)]},
	   @{[SQL_escape($paper_time)]},
	   @{[SQL_escape($paper_endtime)]},
           'SoftConf'
	  );
EOM
  }

  # ticket 107574 point 4 - submission_persons shoudl be printed only once.
  if ($paper_sqlite_DATE_once{$thePaperID}) {
    return;
  }
  $paper_sqlite_DATE_once{$thePaperID} = 1;

  foreach my $c (keys %contact) {
    if ($contact{$c}{Email} || $contact{$c}{Firstname} || $contact{$c}{Lastname} || $contact{$c}{Affiliation} || $contact{$c}{Country}) {
      $presentations_id++;
      $SQL_output .=<<EOM;

INSERT INTO `submission_persons` (`pid`, `order`, `title`, `firstname`, `firstname_short`, `lastname`, `position`, `affiliation`, `country`, `memo`, `email`, `data_from`) VALUES (
	       @{[SQL_escape_integer($thePaperID)]},
	       @{[SQL_escape($c)]},

	       NULL,
	       @{[SQL_escape($contact{$c}{Firstname})]},
	       NULL,
	       @{[SQL_escape($contact{$c}{Lastname})]},

	       NULL,
	       @{[SQL_escape($contact{$c}{Affiliation})]},
	       @{[SQL_escape($contact{$c}{Country})]},

	       NULL,
	       @{[SQL_escape($contact{$c}{Email})]},
               'SoftConf'
	      );

EOM
    }
  }
}

1;

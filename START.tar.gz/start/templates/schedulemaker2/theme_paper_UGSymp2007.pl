# Template used for the first time in UGSymp2007

sub generate_paper() {
    $paperID = $thePaperID;

    @theAuthorList = ();
    @theAffiliationList = ();
    @theAddressList = ();
#    %aPresenter = (); not here... it should be put just before the getSubmitLog but it is not inside this function!

    my @theContacts = ();

    my @XtheContacts = (keys %contact);

    my @_names = ();

    foreach my $thisOne (@XtheContacts) {
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $thisName = "$fn$ln";
	if ($fn && $ln) {
	    push @theContacts, $thisOne;
	    push @_names, $thisName;
	}
    }

    @XtheContacts = @theContacts;
    @theContacts = ();
    while (@XtheContacts) {
	my $thisOne = shift @XtheContacts;
	my $thisName = shift @_names;
	if (!(grep(/^$thisName$/, @_names))) {
	    push @theContacts, $thisOne;
	}
    }

    @theContacts = sort {bynum()} @theContacts;

    foreach my $thisOne (@theContacts) {
	
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	if ($fn =~ /\//) {
	    my @fnList = split(/\b*\/\b*/, $fn);
	    my $mI = $fnList[1];
	    $mI =~ s/\.//g;
	    $mI .= '.';
	    $fn = qq{$fnList[0] $mI};
	}
	
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $thisName = "$fn $ln";

	if ($aPresenter{$thisOne}) {
	    $thisName = qq{<u>$thisName</u>};
	}
	
	if ($thisOne eq $theSupervisor) {
	    $thisName .= '*';
	}
	
	push @theAuthorList, $thisName;

	my $aff = killtheSpace($contact{$thisOne}{Affiliation});
	$aff =~ s/\n//g;
	push @theAffiliationList, $aff;

	my $addr = ();
	
	my $affdpt = killtheSpace($contact{$thisOne}{AffiliationDpt});
	$affdpt =~ s/\n//g;
	if ($affdpt) {
	    $addr .= "$affdpt, ";
	}
	
	my $street = killtheSpace($contact{$thisOne}{Address});
	$street =~ s/\n/, /g;
	if ($street) {
	    $addr .= "$street, ";
	}
	
	my $city = killtheSpace($contact{$thisOne}{Town});
	$city =~ s/\n//g;
	if ($city) {
	    $addr .= "$city, ";
	}
	
	if (!$contact{$thisOne}{Country}) {
	    $contact{$thisOne}{Country} = 'US';
	}
	
	if ($contact{$thisOne}{Country} eq 'US') {
	    my $state = killtheSpace($contact{$thisOne}{State});
	    $state =~ s/\n//g;
	    $state =~ /(- )(..)$/;
	    my $_cState = $2;
	    $state = ($_cState) ? $_cState : $state;
	    if ($state) {
		$addr .= "$state ";
	    }
	}
	else {
	    my $Xcountry = country($contact{$thisOne}{Country});
	    if ($Xcountry) {
		$addr .= "$Xcountry ";
	    }
	}
	
	my $zip = killtheSpace($contact{$thisOne}{Zip});
	$zip =~ s/\n//g;
	if ($zip) {
	    $addr .= "$zip, ";
	}
	
	$addr =~ s/(,[ ])*$//;
	$addr =~ s/^([ ]*,)//;
	
	push @theAddressList, $addr;
	
	$sup[$thisOne-1] = ();
    }

# OK, now that we have the names, affiliations, and addresses,
# let's get the superscripts in there correctly.
 

    $supAddress = q{<table cellpadding=0 cellspacing=0>};
    @supAuthorList = ();
    
    my $supCT = 1;
    my @sup = ();
    for (my $i = 0; $i <= $#theAffiliationList; $i++) {
	if (!$sup[$i]) {
	    $sup[$i] = $supCT++;
	    $supAuthorList[$i] = 
		qq{$theAuthorList[$i]<sup>$sup[$i]</sup>};
            $supAddress .= qq{<tr><td valign=top>$theAffiliationList[$i]<sup>$sup[$i]</sup>, $theAddressList[$i]</td></tr>};

	}
	for (my $j = $i+1; $j <= $#theAffiliationList; $j++) {
	    if (!$sup[$j]) {
		if (lc($theAffiliationList[$i]) eq 
		    lc($theAffiliationList[$j])) {
		    $sup[$j] = $sup[$i];
		    $supAuthorList[$j] = 
			qq{$theAuthorList[$j]<sup>$sup[$i]</sup>};
		}
	    }
	}
    }

    $supAddress .= qq{</table>};
    
    $X_Address = ();

    if ($supCT eq 2) {
	$X_Address .= qq{$theAffiliationList[0], };
        $X_Address .= qq{$theAddressList[0], };

    }
    else {
	$X_Address = $supAddress;
	@theAuthorList = @supAuthorList;
    }
    
    $X_Address =~ s/(,[ ])*$//;
    $X_Address =~ s/^([ ]*,)//;
    $X_Address =~ s/\Q<td valign=top>,\E/<td valign=top>/g;

    $X_Authors = ();
    if ($#theAuthorList eq 0) {
	$X_Authors = $theAuthorList[0];
    }
    if ($#theAuthorList eq 1) {
	$X_Authors = qq{$theAuthorList[0] and $theAuthorList[1]};
    }
    
    if ($#theAuthorList > 1) {
	$X_Authors = join(',&nbsp;&nbsp;', @theAuthorList);
    }
    
    $X_Email = $email;
    $X_Email = qq{<a href="mailto:$X_Email">$X_Email</a>};
    
    $X_Title = killtheSpace(uc($title));
    $X_Title =~ s/\n//g;

    $T_StartTime = deNormalizeTime($paper_time);
    $T_EndTime = deNormalizeTime($paper_endtime);
#   $T_Duration = $SchedRow{$pres}{paperDuration}; seems not used

    my @_paperFiles = bsd_glob("$PC/papers/$paperID.*");
    foreach my $abFile (@_paperFiles) {
	copy($abFile, "$acceptedDir");
    }
    
    local $MANUSCRIPTS = makeMSList($paperID);
    $MANUSCRIPTS =~ s/scmd.cgi\?scmd=getPaper\&//g;
    $MANUSCRIPTS =~ s/paperID=$paperID//g;
    $MANUSCRIPTS =~ s/\&filename=//g;
    
    evalCustFileToFile("schedulemaker2/theme_paper_UGSymp2007_eachabstract.html",
		   "$acceptedDir/$paperID.html");

    $Summary .= evalCustFile("schedulemaker2/theme_paper_UGSymp2007_each.html");
}

1;

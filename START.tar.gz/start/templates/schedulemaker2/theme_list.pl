# This perl file contains the index of the themes supported by the schedulemaker2

#
# Single objects descriptions
#

# # the data are stored following this scheme:
# # <object kind>_<object symbol> => <detailed description>

%templates_description =
  (
   'conference_ISQED07'     => 'The conference name is on the top, with a Times New Roman font.',
   'conference_ISQED10'     => 'The conference name is on the top, with a Times New Roman font.',
   'conference_UGSymp2007'  => 'The conference name is on the top, with an Arial font.',
   'conference_text'        => 'This template just produces a text schedule, useful for including in the proceedings.',
   'conference_excel'       => 'This template just produces an Excel shedule, one line for each item into the schedule, with additional information such as authors, e-mails, phones, and so on. Useful for inclusion in the proceedings, or for publishing reasons.',
   'conference_pdf'         => 'This template produces a single PDF File to be used as conference proceedings.',
   'conference_bibtex'      => 'This template just produces a bibtext schedule, useful for creating a BibTex library.',

   'day_empty'              => 'Days are not displayed.',
   'day_fieldset'           => 'Days are displayed inside a frame.',
   'day_text'               => 'This template displays the day in pure text.',
   'day_excel'              => 'This template displays the day in a line of an Excel file.',
   'day_pdf'                => 'This template simply does not show the day information in the proceedings.',

   'section_ISQED07'        => 'Simple section header with, in order, code, date, time, and title. The section is centered.',
   'section_UGSymp2007'     => 'Simple section header with, in order, title, date, and chair. The section is left aligned.',
   'section_ICFP08'         => 'Simple section header with, in order, time, title. The section is left aligned.',
   'section_text'           => 'Pure text simple section header with, in order, code, date, time, and title.',
   'section_excel'          => 'This template displays the section in a line of an Excel file.',
   'section_pdf'            => 'This template adds a section description in the generated PDF proceedings.',
   'section_pdf'            => 'This template adds a section description in the generated PDF proceedings.',

   'paper_ISQED07'          => "For each submission: time, subcode (Underlined if the submission Flag field contains \"U\"), bold title, $authorWordLC and affiliations. Affiliations are collapsed, and superscripts are generated for $authorWordLC.",
   'paper_ISQED07pid'       => "For each submission: Paper ID, time, subcode (Underlined if the submission Flag field contains \"U\"), bold title, $authorWordLC and affiliations. Affiliations are collapsed, and superscripts are generated for $authorWordLC.",
   'paper_ISQED10'          => "For each submission: time, subcode (Underlined if the submission Flag field contains \"U\"), bold title, $authorWordLC and affiliations. Affiliations are collapsed, and superscripts are generated for $authorWordLC. Improved SEO and XHTML generation.",
   'paper_UGSymp2007'       => "For each submission: time, $authorWordLC, address, email. Each submission Affiliations are collapsed, and superscripts are generated for $authorWordLC. Abstracts which includes the final submissions.",
   'paper_text'             => "Pure text. For each submission: time, subcode, bold title, $authorWordLC and affiliations. Affiliations are collapsed, and notes (n) are generated for $authorWordLC.",
   'paper_excel'            => "This template displays the paper in a line of an Excel file, with collapsed affiliations.",
   'paper_pdf'              => "This template adds one of the file attachments listed into the \"PDF Proc.\" Tab to the conference proceedings",
   'paper_pdf_skip'         => "This template adds one of the file attachments listed into the \"PDF Proc.\" Tab to the conference proceedings. Submissions with non existing file are skipped.",
   'paper_bibtex'           => "Bibtex. For each submission a bibtex entry is printed.",

   'genericspeech_ISQED07'  => "For each generic item: time, subcode, bold title, presenter.",
   'genericspeech_text'     => "Pure Text. For each generic item: time, subcode, bold title, presenter.",
   'genericspeech_excel'    => "This template displays the generic speech in a line of an Excel file.",
   'genericspeech_pdf'      => "This template simply does not show the generic speech."
);


# this function is used to create a "generic" description; to be used when not a better description is available
sub generateThemeDescription {
  my $arg = shift @_;
  my $retvalue = '' ;
  my @splitted = split(/\|/, $arg);
  $retvalue = '<ul>';
  $retvalue .= '<li>' . $templates_description{'conference_'   .$splitted[0]};
  $retvalue .= '<li>' . $templates_description{'day_'          .$splitted[1]};
  $retvalue .= '<li>' . $templates_description{'section_'      .$splitted[2]};
  $retvalue .= '<li>' . $templates_description{'paper_'        .$splitted[3]};
  $retvalue .= '<li>' . $templates_description{'genericspeech_'.$splitted[4]};
  $retvalue .= '</ul>';

  return $retvalue;
}




#
# Themes
#

# template entries: conference|day|section|paper|genericspeech
# the ID put here corresponds to the file name
%themes_templates = (
#             conference|day|section|paper|generic

  'HTML1'    => 'ISQED07|empty|ISQED07|ISQED07|ISQED07',
  'HTML1pid' => 'ISQED07|empty|ISQED07|ISQED07pid|ISQED07',
  'HTML1_10' => 'ISQED10|empty|ISQED07|ISQED10|ISQED07',
  'HTML2'    => 'UGSymp2007|empty|UGSymp2007|UGSymp2007|ISQED07',
  'HTML3'    => 'DIMVA|DIMVA|DIMVA|DIMVA|DIMVA',
  'HTML4'    => 'DIMVA|DIMVA|DIMVA|DIMVAnopapers|DIMVA',
  'HTML5'    => 'DIMVA|DIMVA|DIMVA|DIMVAnoabstracts|DIMVA',
  'HTML6'    => 'DIMVA|DIMVAlistonly|DIMVAlistonly|DIMVAlistonly|DIMVAlistonly',
  'HTML7'    => 'DIMVA|DIMVA|DIMVA|DIMVAnoAffiliationsNoPapers|DIMVA',
  'HTML8_minimal' => 'minimal|minimal|minimal|minimal|minimal',
  'HTML9_DATE' => 'DATE|DATE|DATE|DATE|DATE',
  'HTML10' => 'CS|CS|CS|CS|CS',
  'excel10' => 'CSexcel|empty|empty|CSexcel|empty',
  'DSLIST'   => 'DSLIST|empty|DSLIST|DSLIST|empty',
  'text'     => 'text|text|text|text|text',
  'excel'    => 'excel|excel|excel|excel|excel',
  'PDF1'     => 'pdf|empty|pdf|pdf|pdf',
  'PDF2'     => 'pdf|empty|pdf|pdf_skip|pdf',
  'bibtex'   => 'bibtex|text|text|bibtex|text',
  'sqlite_DATE' => 'sqlite_DATE|sqlite_DATE|sqlite_DATE|sqlite_DATE|sqlite_DATE',
);


%themes_list = (
  'HTML1'     => 'HTML Times (ISQED)|' . generateThemeDescription($themes_templates{'HTML1'}),

  'HTML1pid'  => 'HTML Times with paper ID|' . generateThemeDescription($themes_templates{'HTML1pid'}),

  'HTML1_10'  => 'HTML Times (ASQED 2010)|' . generateThemeDescription($themes_templates{'HTML1_10'}),

  'HTML2'     => 'HTML Arial (UGSymp)|' . generateThemeDescription($themes_templates{'HTML2'}),

  'HTML3'     => 'HTML Gray (DIMVA)| Nice tabular view with links to abstracts, and link to papers. <br> Affiliation are collapsed.<br>Time is not interpreted.<br>Additional author index is generated.<br><b>Uses up to three attachments, one for each column.</b>',

  'HTML4'     => 'HTML Gray without papers (DIMVA)| Nice tabular view with links to abstracts. No link to papers. <br> Affiliation are collapsed.<br>Time is not interpreted.',

  'HTML5'     => 'HTML Gray without abstract page (DIMVA)| Nice tabular view with link to papers. <br> Affiliation are collapsed.<br>Time is not interpreted.<br>Commented links are inserted for pictures and presentations<br><b>Uses up to three attachments, one for each column.</b>',

  'HTML6'     => 'HTML Gray list only (DIMVA)| Nice tabular view without other links. <br> Affiliation are collapsed.<br>Time is not interpreted.',

  'HTML7'     => 'HTML Gray - no papers or affiliations| Nice tabular view with links to abstracts. No link to papers. <br> No author affiliations.<br>Time is not interpreted.',

  'HTML8_minimal'     => 'HTML Minimal| Minimal theme useful for having a quick representation list. The list contains days, sections, paper title, presenter, and has a link to the file. The Presenter is collected with a TextBox item with a field with value <tt>Presenter</tt> in a custom submission page.<br><b>Uses the first attachment only.</b>',

  'HTML9_DATE'     => 'HTML report (DATE)| Theme used by the DATE conference. It produces 1 page for each session. Typically made for a track. The list contains sections, paper title, presenter, and no link to files; days are not supported.',

  'HTML10'     => 'HTML Presentations | Theme produces one entry for each presentation, with session number, title, authors, affiliations, abstracts, and contact author.',


  'DSLIST'     => 'Ordered detailed submission list| Abstracts In-Line. <br> No sessions, days or times.',

  'text'      => 'Pure Text|Pure text output. This theme generates a text-only schedule.',

  'excel'     => 'Excel|Excel output. A spreadsheet is generated with the list of submissions selected for the schedule.',

  'excel10'     => 'Excel Presentations | Excel spreadsheet with columns for presentation code, title, and authors affiliations and abstracts.',


  'PDF1'      => 'PDF proceedings|PDF Proceedings. An additional archive is created with the Latex files used for the generation, allowing a fine tune of the result. <br> Day and Generic speech entries are ignored. <br> The PDF will be generated only if the titles will contain legal Latex characters. otherwise, a latex error will happen, which can be looked up into the log. <br><b>Uses the first attachment only.</b><br> Since it is not yet guaranteed that a PDF willcome out whatever the input is, please consider this option as a BETA VERSION.',

  'PDF2'      => 'PDF proceedings (with skip)|PDF Proceedings. An additional archive is created with the Latex files used for the generation, allowing a fine tune of the result. <br> Day and Generic speech entries are ignored. <br> The PDF will be generated only if the titles will contain legal Latex characters. otherwise, a latex error will happen, which can be looked up into the log. <br> In this version, submissions with non existing files are <b>SKIPPED</b>.<br><b>Uses the first attachment only.</b><br> Since it is not yet guaranteed that a PDF willcome out whatever the input is, please consider this option as a BETA VERSION.',

  'bibtex'    => 'BibTex|BibTex output. A text file is generated with a list of bibtex entries of the accepted papers. The template generates a unique bibtex ID, plus authors and title. The Bibtex default content is then added to each entry.',

  'sqlite_DATE' => 'SQLite (DATE)|SQLite dump output for DATE online schedule.',
);


# when no theme is specified, use this one!
$themes_default_nick = 'HTML9_DATE';



1;

# Template used for the first time in ISQED07

sub generate_section() {
  $Summary .= evalCustFile('schedulemaker2/theme_section_ISQED07_header.html');
}


1;

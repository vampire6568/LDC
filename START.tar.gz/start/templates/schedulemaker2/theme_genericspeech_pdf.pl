sub generate_genericspeech() {
    return '';
}

1;

sub generate_genericspeech() {
  $Summary .= evalCustFile("schedulemaker2/theme_genericspeech_DATE_each.html");
}

1;

# Karly Excel Generator.

sub generate_paper() {
    $paperID = $thePaperID;
    $X_Slot = $paper_subcode;
    $X_Underline = ($paper_flag =~ /U/i) ? 1 : 0;

    $record = ();

    # Paper code - subcode necessary here.
    $paper_session_code_subcode = $section_code . '.' . $paper_subcode;
    $record .= $paper_session_code_subcode . $logsep;


    @theAuthorList = ();
    @theAffiliationList = ();
    @theAddressList = ();

    my @theContacts = ();
    
    my @XtheContacts = (keys %contact);

    my @_names = ();

    foreach my $thisOne (@XtheContacts) {
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
	my $thisName = "$fn$ln";
	if ($fn && $ln) {
	    push @theContacts, $thisOne;
	    push @_names, $thisName;
	}
    }
    # _names contains PaoloGai,RichGerber
    # theContacts contains 1,2

    # now removes duplicate names
    @XtheContacts = @theContacts;
    @theContacts = ();
    while (@XtheContacts) {
	my $thisOne = shift @XtheContacts;
	my $thisName = shift @_names;
	if (!(grep(/^$thisName$/, @_names))) {
	    push @theContacts, $thisOne;
	}
    }

    @theContacts = sort {bynum()} @theContacts;

    $correspondingContactIndex = 0;
    $correspondingContactFound = 0;


    my @cityStateCountryList = ();

    foreach my $thisOne (@theContacts) {
	
	my $fn = killtheSpace($contact{$thisOne}{Firstname});
	if ($fn =~ /\//) {
	    my @fnList = split(/\b*\/\b*/, $fn);
	    my $mI = $fnList[1];
	    $mI =~ s/\.//g;
	    $mI .= '.';
	    $fn = qq{$fnList[0] $mI};
	}
	
	my $ln = killtheSpace($contact{$thisOne}{Lastname});
        if (!$correspondingContactFound) {
	    if ((lc($ln) eq lc($contactLastname)) && 
		(($contactFirstname =~ /^$fn/i) || ($fn =~ /^$contactFirstname/i))) {
		$correspondingContactFound = 1;
	    }
	    else {
		$correspondingContactIndex++;
	    }
	}

        # Update list for author index
        my $uniqueAuthorKey = lc(transOddChars("$ln $fn"));
        $GlobalAuthorIndex{$uniqueAuthorKey}{Lastname} = $ln;
        $GlobalAuthorIndex{$uniqueAuthorKey}{Firstname} = $fn;
        $GlobalAuthorIndex{$uniqueAuthorKey}{Sessions} .= ":$paper_session_code_subcode";

	my $thisName = "$fn $ln";

	push @theAuthorList, $thisName;

	my $aff = killtheSpace($contact{$thisOne}{Affiliation});
	$aff =~ s/\n//g;
	push @theAffiliationList, $aff;

        my $city = killtheSpace($contact{$thisOne}{City});
        my $state = killtheSpace($contact{$thisOne}{State});
        my $country = killtheSpace($contact{$thisOne}{Country});
	my $cityStateCountry = ();
	if ($city) {
	    $cityStateCountry .= ", $city";
	}
	if ($state) {
	    $cityStateCountry .= ", $state";
	}
	if ($country) {
	    $cityStateCountry .= ", $country";
	}
	$cityStateCountry =~ s/\Q,\E$//;
	$cityStateCountry =~ s/[\Q,\E ]*$//;
	push @cityStateCountryList, $cityStateCountry;

	$sup[$thisOne-1] = ();
    }

# OK, now that we have the names, affiliations, and addresses,
# let's get the superscripts in there correctly.
 

    $supAddress = q{<table cellpadding=0 cellspacing=0>};
    @supAuthorList = ();
    
    my $supCT = 1;
    my @sup = ();
    for (my $i = 0; $i <= $#theAffiliationList; $i++) {
	if (!$sup[$i]) {
	    $sup[$i] = $supCT++;
	    $supAuthorList[$i] = 
		qq{$theAuthorList[$i]&nbsp;($sup[$i])};
	    $supAddress .= qq{<tr><td valign=top><em>($sup[$i]) $theAffiliationList[$i]$cityStateCountryList[$i]</em></td></tr>};
	}
	for (my $j = $i+1; $j <= $#theAffiliationList; $j++) {
	    if (!$sup[$j]) {
		if (lc($theAffiliationList[$i]) eq 
		    lc($theAffiliationList[$j])) {
		    $sup[$j] = $sup[$i];
		    $supAuthorList[$j] = 
			qq{$theAuthorList[$j]&nbsp;($sup[$i])};
		}
	    }
	}
    }

    $supAddress .= qq{</table>};
    
    $X_Address = ();

# Commented lines here for Karly in HPV Conference

#    if ($supCT eq 2) {
#	$X_Address .= qq{<em>$theAffiliationList[0]$cityStateCountryList[0]</em>,};
#    }
#    else {
	$X_Address = $supAddress;
	@theAuthorList = @supAuthorList;
#    }
    
    $X_Address =~ s/\Q,\E$//;
    $X_Address =~ s/(,[ ])*$//;
    $X_Address =~ s/^([ ]*,)//;
    $X_Address =~ s/\Q<td valign=top>,\E/<td valign=top>/g;

    $X_Authors = ();

    # Boldface for first author

    if ($correspondingContactFound) {
	$theAuthorList[$correspondingContactIndex] = "<u>$theAuthorList[$correspondingContactIndex]</u>";
    }

    if ($#theAuthorList eq 0) {
	$X_Authors = $theAuthorList[0];
    }
    if ($#theAuthorList eq 1) {
	$X_Authors = qq{$theAuthorList[0],&nbsp;$theAuthorList[1]};
    }
    
    if ($#theAuthorList > 1) {
	$X_Authors = join(',&nbsp;', @theAuthorList);
    }
    
    $X_AuthorsNoNumbers = $X_Authors;
    $X_AuthorsNoNumbers =~ s/&nbsp;*\([0-9]*\)[\s ]*//g;
    $X_AuthorsNoNumbers =~ s/[\s ]*\([0-9]*\)[\s ]*//g;


    $X_Email = $email;
    $X_Email = qq{<a href="mailto:$X_Email">$X_Email</a>};
    
    $X_Title = killtheSpace($title);
    $X_Title =~ s/\n//g;
    $record .= $X_Title . $logsep;


    $T_StartTime = $paper_time;
    $T_EndTime = $paper_endtime;
#    $T_StartTime = deNormalizeTime($paper_time);
#   $T_Duration = $SchedRow{$pres}{paperDuration}; seems not used for ISQED

#    my @_paperFiles = bsd_glob("$PC/papers/$paperID.*");
#    foreach my $abFile (@_paperFiles) {
#	copy($abFile, "$acceptedDir");
#    }
    
#    local $MANUSCRIPTS = makeMSList($paperID);
#    $MANUSCRIPTS =~ s/scmd.cgi\?scmd=getPaper\&//g;
#    $MANUSCRIPTS =~ s/paperID=$paperID//g;
#    $MANUSCRIPTS =~ s/\&filename=//g;
    

    $V_StartTime = $T_StartTime;
    $V_StartTime =~ s/ //g;
    $V_EndTime = $T_EndTime;
    $V_EndTime =~ s/ //g;
    $V_Address = $X_Address;
    $V_Address =~ s/(\<table)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<\/table)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<td)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<\/td)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<tr)([^\>]*)(\>)//g;
    $V_Address =~ s/(\<\/tr)([^\>]*)(\>)/, /g;
    $V_Address =~ s/(,[ ])*$//;
    $V_Address =~ s/^([ ]*,)//;

    # handle PDF papers, reset to 0
    $paperpresent = 0;
    $papernolinks = 1;



    $record .=<<EOM;
$X_Authors<br>
<P>
<em>$X_Address</em>
<p>
$absHTML
<p>
<b>Contact</b>: $contactFirstname $contactLastname, $email
EOM

    $record .= $logsep;

    $record .=<<EOM;
$X_Authors<br>
<P>
<em>$X_Address</em>
<p>
<b>Contact</b>: $contactFirstname $contactLastname, $email
EOM

    $record .= $logsep;


    if (defined &generate_conference_excel_generateline) {
	generate_conference_excel_generateline();
    }


}

1;

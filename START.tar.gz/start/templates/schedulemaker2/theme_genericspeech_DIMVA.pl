sub generate_genericspeech() {
    $Summary .= evalCustFile("schedulemaker2/theme_genericspeech_DIMVA_each.html");
}

1;

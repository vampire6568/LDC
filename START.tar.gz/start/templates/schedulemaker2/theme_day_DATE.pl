# Template used for the first time in RTSS08

sub generate_day() {
  # days are hidden in DATE
  # $Summary .= evalCustFile('schedulemaker2/theme_day_DATE.html');
}


1;

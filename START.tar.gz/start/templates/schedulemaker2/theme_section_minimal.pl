sub generate_section() {
  $Summary .=<<EOM;
    <table>
      <tr>
	<td valign=top>
	  $section_time@{[($section_endtime) ? qq{&nbsp;-&nbsp;$section_endtime} : qq{} ]}&nbsp;&nbsp;
	</td>
	<td valign=top>
	  @{[($section_code) ? qq{Session $section_code - } : qq{}]}
	  <b>$section_title</b>
	  @{[($section_room) ? qq{ - $section_room} : qq{}]}

	  @{[($section_description   ) ? qq{<br>Description:          $section_description   }:()]}

	  @{[($section_chair         ) ? qq{<br>Chair:                $section_chairfirstname $section_chair         }:()]}
	  @{[($section_chairaff      ) ? qq{<br>Chair Affiliation:    $section_chairaff      }:()]}
	  @{[($section_chairemail    ) ? qq{<br>Chair Email:          $section_chairemail    }:()]}
	  @{[($section_chaircountry  ) ? qq{<br>Chair Country:        $section_chaircountry  }:()]}
	  @{[($section_chairphone    ) ? qq{<br>Chair Phone:          $section_chairphone    }:()]}

	  @{[($section_cochair       ) ? qq{<br>Co-Chair:             $section_cochairfirstname $section_cochair       }:()]}
	  @{[($section_cochairaff    ) ? qq{<br>Co-Chair Affiliation: $section_cochairaff    }:()]}
	  @{[($section_cochairemail  ) ? qq{<br>Co-Chair Email:       $section_cochairemail  }:()]}
	  @{[($section_cochaircountry) ? qq{<br>Co-Chair Country:     $section_cochaircountry}:()]}
	  @{[($section_cochairphone  ) ? qq{<br>Co-Chair Phone:       $section_cochairphone  }:()]}

	</td>
      </tr>
    </table>
EOM
}


1;

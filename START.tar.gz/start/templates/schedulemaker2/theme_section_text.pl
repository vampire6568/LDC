# Template used for the first time in RTSS08

sub generate_section() {
  $Summary .= evalCustFile('schedulemaker2/theme_section_text_header.txt')."\n\n";
}


1;

sub generate_conference_header() {
  if ($trackName) {
    importTrackInfo();
    getUserInfo();

    # create the list of track managers as seen in the track administration console
    @_currAdminList = ();
    if (%{$TrackAdmin{$trackName}}) {
      my @tguys = (values %{$TrackAdmin{$trackName}});
      if (@tguys) {
	push @_currAdminList, @tguys;
      }
    }
    # Get the current administrators which may not be entered via the multi-track console;
    push @_currAdminList, getUsersInGroup($trackName . '_manager');
    @_currAdminList = uniq(\@_currAdminList); # no dups.
    @_currAdminList = grep {($_)} @_currAdminList;  # no empties;

    foreach $tm (@_currAdminList) {
      $trackchairlist .=<<EOM;
   <li>$FirstName{$tm} $LastName{$tm} ($Email{$tm}@{[$Affiliation{$tm} ? qq{, $Affiliation{$tm}}:qq{}]})</li>
EOM
    }
  }


  $Summary = evalCustFile('schedulemaker2/theme_conference_CS_header.html');
}

sub generate_conference_footer() {

    if ($CategoryName{2} && $CategoryBox{2}) {
	my @cats = split(/\n/, $CategoryBox{2});
	foreach my $cat (@cats) {
	    if ($TopicSummary{"$cat"}) {
		$SummaryOfTopics .= qq{<br><br><br><h1 style="text-align:center;">$cat</h1><p><table cellspacing=10><tbody>};
		$SummaryOfTopics .= $TopicSummary{"$cat"} . "</tbody></table>";
            }
	}
    }


    $authorIndexList = ();
    @orderedKeys = sort {lc($GlobalAuthorIndex{$a}{Firstname}) cmp lc($GlobalAuthorIndex{$b}{Firstname})} (keys %GlobalAuthorIndex);
    @orderedKeys = sort {lc($GlobalAuthorIndex{$a}{Lastname}) cmp lc($GlobalAuthorIndex{$b}{Lastname})} @orderedKeys;


    my @firstLetters = map {substr $GlobalAuthorIndex{$_}{Lastname}, 0, 1} @orderedKeys;

    my $currfirst = '1';

    foreach my $key (@orderedKeys) {
	my $thisfirst = shift @firstLetters;
	if (lc($currfirst) ne lc($thisfirst)) {
	    $currfirst = $thisfirst;
	    $authorIndexList .= qq{<h2 class="smally">$currfirst</h2>};
	}

	$authorIndexList .= "$GlobalAuthorIndex{$key}{Lastname}, $GlobalAuthorIndex{$key}{Firstname}:";
	my $s = $GlobalAuthorIndex{$key}{Sessions};
	$s =~ s/\Q:\E/,/g;
	$s =~ s/(,[ ])*$//;
	$s =~ s/^([ ]*,)//;
	$authorIndexList .= "$s<br>";
    }

    $Summary .= evalCustFile('schedulemaker2/theme_conference_CS_footer.html');

  my @_FXList = ("schedule.css");

  foreach my $_file (@_FXList) {
    copy("$templates/schedulemaker2/theme_conference_CS_files/$_file", "$acceptedDir/$_file");
  }

  # write the file!
  open(THEFILE, ">$acceptedDir/accepted.html");
  binmode(THEFILE);
  print THEFILE "$Summary";
  close THEFILE;
}

1;

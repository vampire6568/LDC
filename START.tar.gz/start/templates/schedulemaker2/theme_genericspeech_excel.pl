# Template used for the first time in ISQUED09

$schedulemaker2_excel_genericspeech_col_caption = 
    'Generic Speech Title'     . $logsep .
    'Generic Speech Presenter' . $logsep .
    'Generic Speech Time'      . $logsep .
    'Generic Speech End Time'  . $logsep .
    'Generic Speech Subcode'   . $logsep;
$schedulemaker2_excel_genericspeech_col_num = 4;


sub generate_genericspeech() {
    if (!$record) {
	# no record, we have to insert all the spaces
	for ($i=0; $i<$schedulemaker2_excel_day_col_num +
	              $schedulemaker2_excel_section_col_num +
	              $schedulemaker2_excel_paper_col_num; $i++) {
	    $record .= $logsep;
	}
    } else {
	# there is a record, it must be a section, we have to insert the paper spaces
	for ($i=0; $i<$schedulemaker2_excel_paper_col_num; $i++) {
	    $record .= $logsep;
	}
    }

    $record .=
	$genericspeech_title      . $logsep .
	$genericspeech_presenter  . $logsep .
	$genericspeech_time       . $logsep .
        $genericspeech_endtime    . $logsep .
	$genericspeech_subcode    . $logsep;

    if (defined &generate_conference_excel_generateline) {
	generate_conference_excel_generateline();
    }
    return '';



}

1;

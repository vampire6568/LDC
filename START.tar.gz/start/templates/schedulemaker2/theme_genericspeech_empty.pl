sub generate_genericspeech() {
}

1;

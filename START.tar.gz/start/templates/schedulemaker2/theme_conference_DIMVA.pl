sub generate_conference_header() {
  requireCustomizableFile('schedulemaker2/theme_authorindex.pl');

  $Summary = evalCustFile('schedulemaker2/theme_conference_DIMVA_header.html');
}

sub generate_conference_footer() {
  $Summary .= evalCustFile('schedulemaker2/theme_conference_DIMVA_footer.html');

  my @_FXList = ("camera.gif", "paper.jpg", "schedule.css", "slides.jpg", "pictures.html");

  foreach my $_file (@_FXList) {
    copy("$templates/schedulemaker2/theme_conference_DIMVA_files/$_file", "$acceptedDir/$_file");
  }

  # write the file!
  open(THEFILE, ">$acceptedDir/accepted.html");
  binmode(THEFILE);
  print THEFILE "$Summary";
  close THEFILE;


  $aindex = evalCustFile('schedulemaker2/theme_conference_DIMVA_authorindex_header.html');
  $firstletter = '';
  @o = authorindex_getorder();
  use Encode;
  foreach $thekey (@o) {
    # check the first letter

    ##########################################################
    # don't ask me why, but this works.
    # inspiration from http://www.lemoda.net/perl/perl-unicode-tutorial/
    my $k = Encode::decode_utf8($authorindex_lastname{$thekey});
    $k =~ /^(.)/;
    my $fl = encode_utf8($1);
    ##########################################################

    if ($firstletter ne $fl) {
      $firstletter = $fl;
      $aindex .= evalCustFile('schedulemaker2/theme_conference_DIMVA_authorindex_firstletter.html');
    }

    # get the list of papers and print it in a hopefully nice way
    @plist = sort { bynum() } @{$authorindex_paperid{$thekey}};
    uniq(\@plist);
    local $thepaperlist = '';
    my $flag_first = 1;
    foreach $pid (@plist) {
      if ($flag_first) {
	$flag_first = 0;
      } else {
	$thepaperlist .= ', ';
      }
      $thepaperlist .= qq{<a href="$pid.html" target="_blank">$pid</a>}
    }

    # print the item
    $aindex .= evalCustFile('schedulemaker2/theme_conference_DIMVA_authorindex_each.html');
  }
  $aindex .= evalCustFile('schedulemaker2/theme_conference_DIMVA_authorindex_footer.html');


  # write the author index
  open(THEFILE, ">$acceptedDir/authorindex.html");
  binmode(THEFILE);
  print THEFILE $aindex;
  close THEFILE;


}

1;

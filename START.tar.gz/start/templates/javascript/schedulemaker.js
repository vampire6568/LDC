	prefix_day = 'day_';
	prefix_section = 'section_';
	prefix_paper = 'paper_';
	separator_line = "|";
	separator_equal = "=";
	separator_comma = ",";

	conferences = ['daylist','theconference'];
	days = ['sectionlist'];
	sections = ['paperlist'];

	function createNewDay(name) {
			var newDiv = document.getElementById("template_day").cloneNode(true);
			newDiv.id = prefix_day + (days.length);

			days.push(newDiv.id);
			$('daylist').appendChild(newDiv);
			Effect.Appear(newDiv.id);
  			destroySectionItemSortables(); 
			destroyDayItemSortables();
			createSectionItemSortables();
			createDayItemSortables();
			createConferenceSortable();
	}


	function createNewSection(name) {
			var newDiv = document.getElementById("template_section").cloneNode(true);
			newDiv.id = prefix_section + (sections.length);

			sections.push(newDiv.id);
			$('sectionlist').appendChild(newDiv);
			Effect.Appear(newDiv.id);
  			destroySectionItemSortables(); 
			destroyDayItemSortables();
			createSectionItemSortables();
			createDayItemSortables();
			createConferenceSortable();
	}


	function createDayItemSortables() {
		for(var i = 0; i < days.length; i++) {
			Sortable.create(days[i],{tag:'div',dropOnEmpty: true, containment: days,only:'sectionitem',handle:'handlesection'});
		}
	}


	function createSectionItemSortables() {
		for(var i = 0; i < sections.length; i++) {
			Sortable.create(sections[i],{tag:'div',dropOnEmpty: true, containment: sections,only:'paperitem'});
		}
	}


	function destroyDayItemSortables() {
		for(var i = 0; i < days.length; i++) {
			Sortable.destroy(days[i]);
		}
	}

	function destroySectionItemSortables() {
		for(var i = 0; i < sections.length; i++) {
			Sortable.destroy(sections[i]);
		}
	}

	function createConferenceSortable() {
		for(var i = 0; i < conferences.length; i++) {
			Sortable.create(conferences[i],{tag:'div',dropOnEmpty: true, containment: conferences,only:'dayitem',handle:'handleday'});
		}
	}


	function saveSchedule() {
		var finaltext = '';

		var daystext = '';
		daystext += 'theconference' + separator_equal;
		var mydays = Sortable.sequence('theconference');
		for(var i = 0; i < mydays.length; i++) {
			var theday = prefix_day + mydays[i];
			if (i!=0) daystext += separator_comma;
			daystext += theday;

			var sessionstext = theday + separator_equal;
			var mysessions = Sortable.sequence(theday);
			for(var j = 0; j < mysessions.length; j++) {
				var thesession = prefix_section + mysessions[j];
				if (j!=0) sessionstext += separator_comma;
				sessionstext += thesession;

				var paperstext = thesession + separator_equal;
				var mypapers = Sortable.sequence(thesession);
				for(var k = 0; k < mypapers.length; k++) {
					var thepaper = prefix_paper + mypapers[k];
					if (k!=0) paperstext += separator_comma;
					paperstext += thepaper;
				}
				finaltext += paperstext + separator_line;
			}
			finaltext += sessionstext + separator_line;
		}
		finaltext += daystext + separator_line;

		theschedule = document.getElementById("theschedule");
		theschedule.value = finaltext;

		theaction = document.getElementById("theaction");
		theaction.value = 'saveSchedule';
		
		document.myForm.submit();

		return false;
	}

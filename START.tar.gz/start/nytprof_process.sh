#!/bin/bash

cd /www/profile
for x in `find . -maxdepth 1 -type f`; do
    mkdir xxx
    mv ${x} xxx
    mv xxx ${x}
    cd ${x}
    nytprofhtml -f ${x} -o out
    cd ..
done;
